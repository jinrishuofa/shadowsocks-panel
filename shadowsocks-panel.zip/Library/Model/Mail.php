<?php
/**
 * Project: shadowsocks-panel
 * Author: Sendya <18x@loacg.com>
 * Time: 2016/3/25 23:41
 */


namespace Model;

/**
 * Class Mail
 * @package Model
 */
class Mail {

    public $address;
    public $subject;
    public $content;

}